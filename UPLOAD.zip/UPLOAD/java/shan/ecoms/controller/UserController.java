package shan.ecoms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import shan.ecoms.dao.UserDAO;
import shan.ecoms.model.Login;
import shan.ecoms.model.Register;

@Controller
public class UserController {

/*	@RequestMapping(value="/login")
	public String login()
	{
		return "login";
	}
}*/
	
	@Autowired
	UserDAO userdao;
	
	@RequestMapping(value="login", method=RequestMethod.GET)
	public ModelAndView sendregister(@ModelAttribute("loginuser")Login loginuser)
	{
		System.out.println("in User controller-login");
		ModelAndView mv=new ModelAndView("login");
		return mv;
	}

	@RequestMapping(value="login", method=RequestMethod.POST)
	public ModelAndView getUser(Login loginuser)
	{
		System.out.println("in User controller- login-POST");
		userdao.searchUser(loginuser);
		ModelAndView mv=new ModelAndView("successlogin","loginuser",new Login());
		return mv;			
	}
}



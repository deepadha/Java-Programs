package shan.ecoms.dao;

import shan.ecoms.model.Register;
import shan.ecoms.model.Login;

public interface UserDAO {

	public void addUser(Register user);
	public void searchUser(Login loginuser);
	
}
